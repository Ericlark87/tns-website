// src/api.js
import axios from 'axios';

const api = axios.create({
  baseURL: '/api', // Vite proxy sends this to http://localhost:5000/api
});

export async function pingServer() {
  const res = await api.get('/health');
  return res.data; // { status, message, timestamp }
}

export default api;