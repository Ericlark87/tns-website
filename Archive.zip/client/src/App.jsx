// src/App.jsx
import { useEffect, useState } from 'react';
import { pingServer } from './api';

function App() {
  const [health, setHealth] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    pingServer()
      .then((data) => setHealth(data))
      .catch((err) => {
        console.error('Health check failed:', err);
        setError('Failed to reach backend');
      });
  }, []);

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col items-center justify-center">
      <h1 className="text-3xl font-bold mb-4">Things N Stuff</h1>

      {health && (
        <pre className="bg-slate-800 p-4 rounded text-sm">
          {JSON.stringify(health, null, 2)}
        </pre>
      )}

      {error && (
        <p className="text-red-400 mt-2">
          {error}
        </p>
      )}
    </div>
  );
}

export default App;