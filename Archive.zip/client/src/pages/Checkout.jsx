import React from 'react';
import { API } from '../api';

export default function Checkout() {
  const handleCheckout = async () => {
    try {
      const response = await API.post(
        '/stripe/create-checkout-session',
        {
          items: [
            {
              price_data: {
                currency: 'usd',
                product_data: { name: 'Sample Product' },
                unit_amount: 2000,
              },
              quantity: 1,
            },
          ],
        },
        {
          headers: {
            Authorization: 'Bearer supersecrettoken123',
          },
        }
      );
      window.location.href = response.data.url;
    } catch (err) {
      console.error('Checkout error:', err);
      alert('Checkout failed.');
    }
  };

  return (
    <div className="p-4">
      <h2 className="text-xl font-semibold mb-4">Checkout Page</h2>
      <button
        onClick={handleCheckout}
        className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 transition"
      >
        Buy Now ($20)
      </button>
    </div>
  );
}