import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// Health check route (frontend test)
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    message: 'Backend is alive',
    timestamp: Date.now()
  });
});

// Routes
app.get('/api/products', (req, res) => {
  res.json([{ id: 1, name: 'Test Product', price: 20.00 }]);
});

app.get('/api/test', (req, res) => {
  res.send('✅ Backend test route is working');
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));