import React from 'react';
import { Link, Outlet } from 'react-router-dom';

export default function MainLayout() {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-gray-800 text-white p-4">
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-xl font-bold">
            <Link to="/">ThingsNStuff</Link>
          </h1>
          <nav>
            <ul className="flex gap-4">
              <li><Link to="/">Home</Link></li>
              <li><Link to="/checkout">Checkout</Link></li>
            </ul>
          </nav>
        </div>
      </header>

      {/* Main content */}
      <main className="flex-grow container mx-auto p-4">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-gray-200 text-center text-sm p-4">
        &copy; {new Date().getFullYear()} TNS Enterprises. All rights reserved.
      </footer>
    </div>
  );
}