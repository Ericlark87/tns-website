import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Checkout from './pages/Checkout';

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<h1>Welcome to ThingsNStuff</h1>} />
        <Route path="/checkout" element={<Checkout />} />
        <Route path="/success" element={<h2>Payment successful!</h2>} />
        <Route path="/cancel" element={<h2>Payment cancelled.</h2>} />
        <Route path="*" element={<h2>404 - Page Not Found</h2>} />
      </Routes>
    </Router>
  );
}